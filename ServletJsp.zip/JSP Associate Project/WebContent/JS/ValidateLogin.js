function validateLoginFrm(){
	if(loginForm.associateId.value==""){
		alert("Enter asociateId");
		return false;
	}
	else if(loginForm.password.value==""){
		alert("Enter asociateId");
		return false;
	}
}
function validateRegistrationFrm(){
	if(registerForm.firstName.value==""){
		alert("Enter first Name");
		return false;
	}
	else if(registerForm.lastName.value==""){
		alert("Enter last name");
		return false;
	}
	else if(registerForm.emailId.value==""){
		alert("Enter eamil Id");
		return false;}
	else if(registerForm.department.value==""){
		alert("Enter department");
		return false;}
	else if(registerForm.designation.value==""){
		alert("Enter designation");
		return false;}   
}