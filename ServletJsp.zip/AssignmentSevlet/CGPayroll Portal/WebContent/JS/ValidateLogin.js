function validateLoginFrm(){
    if(LoginForm.associateId.value==""){
        alert("Enter AssociateId");
        return false;
    }
    else if(loginFrom.password.value==""){
        alert("Enter.AssociateId");
        return false;
    }
}

function validateRegistrationForm(){
    if(registerationForm.firstname.value==""){
        alert("Enter firstname");
        return false;
    }
    else if(registerationForm.lastname.value==""){
        alert("Enter lastname");
        return false;
    }
    else if(registerationForm.emailId.value==""){
        alert("Enter emailId");
        return false;
    }else if(registerationForm.department.value==""){
        alert("Enter department");
        return false;
        }
    else if(registerationForm.designation.value==""){
            alert("Enter designation");
            return false;
            }
    else if(registerationForm.basicSalary.value==""){
        alert("Enter basic salary");
        return false;
        }
    else if(registerationForm.bankName.value==""){
        alert("Enter bankName");
        return false;
        }
    else if(registerationForm.accountNo.value==""){
        alert("Enter accountNo");
        return false;
        }
    else if(registerationForm.ifscCode.value==""){
        alert("Enter ifscCode");
        return false;
        }
    
    }
