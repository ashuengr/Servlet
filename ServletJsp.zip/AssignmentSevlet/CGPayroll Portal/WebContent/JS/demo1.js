function sayHello(){
	document.getElementById("msg").innerHTML="<font align=center color=green size=10>Hello World on Browser</font>"
	console.log("Hello")
	}
