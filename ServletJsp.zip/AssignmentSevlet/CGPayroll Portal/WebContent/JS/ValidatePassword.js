function validatePassword(){
	if(changePasswordFrm.password.value.length>=6){
		if(changePasswordFrm.password.value.search(/[0-9]/)!=-1 &&
				changePasswordFrm.password.value.search(/[A-Z]/)!=-1 &&
				changePasswordFrm.password.value.search(/[!@#$%^&*()_+]/)!=-1){
			return true;
		}
		else{
			alert("password must contain atleast 1 number 1 uppercase letter and 1 special character");
			return false;
		}	
	}
	else{
		alert("minimum of 6 character");
		return false;
	}
}
function checkSame(){
	if(changePasswordFrm.password.value!=changePasswordFrm.confirmPassword.value){
		alert("Password and confirm password did not match");
		return false;
	}
}