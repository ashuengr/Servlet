package com.cg.payroll.services;
import com.cg.payroll.daoservices.*;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.exception.AssociateDetailNotFoundException;
import java.util.List;

public class PayrollServiceImpl implements payrollServices  {
	private AssociateDao associateDao=new AssociateDAOImpl();

	@Override
	public int acceptAssociateDetails(Associate associate) {
	    associate=associateDao.save(associate);
		return associate.getAssociateId();
	}
	
	@Override
	public int calculateNetSalary(int associateId) throws AssociateDetailNotFoundException {
		Associate associate = associateDao.findOne(associateId);
		int netSalary =0 ;
		if(associate==null) {
			throw new AssociateDetailNotFoundException("Associate details not found for Id" + associateId);
		}
		else {
			
			int basicSalary = associate.getSalary().getBasicSalary() ;
			int monthlyGrossSalary = (int)(basicSalary + (basicSalary*0.7));
			int annualGrossSalary = 12 * monthlyGrossSalary; 
			int investment = associate.getYearlyInvestmentUnder8oc() + associate.getSalary().getEpf() + associate.getSalary().getCompanyPf() ; 
			if(investment >=150000) {
				investment = 150000;
			}
			//int taxableAmount = annualGrossSalary - associate.getSalary().getEpf() - associate.getSalary().getCompanyPf() ; 
			if(annualGrossSalary<250000) {
				 netSalary = annualGrossSalary - associate.getSalary().getEpf() - associate.getSalary().getCompanyPf() ;
			}
			else if(annualGrossSalary>=250000 && annualGrossSalary<500000){
				 netSalary = (int) (annualGrossSalary - (( annualGrossSalary - investment ) * 0.1 ) - associate.getSalary().getEpf() - associate.getSalary().getCompanyPf());
			}
			else if(annualGrossSalary>=500000 && annualGrossSalary < 1000000) {
				int tax2 = (int) ((annualGrossSalary - 500000) * 0.2);
				int tax1 =  (int) ((250000 - investment)*0.1);
				 netSalary = annualGrossSalary - tax1 - tax2 - associate.getSalary().getEpf() - associate.getSalary().getCompanyPf();
			}
			else if(annualGrossSalary>=1000000) {
				int tax3 = (int) ((annualGrossSalary - 1000000 ) *0.3);
				int tax2 = 100000;
				int tax1  = (int) ((250000 - investment) * 0.1);
				netSalary = annualGrossSalary - tax1 - tax2 - tax3 - associate.getSalary().getEpf() - associate.getSalary().getCompanyPf();
			}
			
			monthlyGrossSalary = netSalary/12;
			associate.getSalary().setNetsalary(netSalary);
			associate.getSalary().setGrossSalary(monthlyGrossSalary);
			associateDao.update(associate);
			return netSalary;
		}   
	}

	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailNotFoundException {
		Associate associate=associateDao.findOne(associateId);
		if(associate==null)
			throw new AssociateDetailNotFoundException("Associate details not found for id"+associateId);
		return associate;
	}

	@Override
	public List<Associate>getAllAssociateDetails() {
		
		return associateDao.findAll();
	}
	
	
} 

	